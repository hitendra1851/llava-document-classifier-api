# llava-document-classifier-api
End-to-end document image classification API using LLaVA (LLaMA 3.2 Vision). Classifies images (invoices, receipts, ID cards, etc.) using a Vision LLM with FastAPI, Docker, and a web UI. Includes training data collection and retraining stubs.
